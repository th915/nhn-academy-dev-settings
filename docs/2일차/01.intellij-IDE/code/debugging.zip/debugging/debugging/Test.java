package debugging;

public class Test {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;

        sum(a, b);
        sub(a, b);
    }

    public static void sum(int a, int b) {
        int result = a + b;
        print(result, "더하기 연산 수행 결과");
    }

    public static void sub(int a, int b) {
        int num = a - b;
        print(num, "빼기 연산 수행 결과");
    }

    public static void print(int num, String message) {
        System.out.println(message + " : " + num);
    }
}